package com.example.Marco.demo.photoz.clone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoPhotozCloneApplicationTests {

	@Test
	void contextLoads() {
	}

}
