package com.example.Marco.demo.photoz.clone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoPhotozCloneApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoPhotozCloneApplication.class, args);
	}

}
